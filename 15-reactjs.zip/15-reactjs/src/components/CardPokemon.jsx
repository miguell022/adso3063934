import './CardPokemon.css';

function CardPokemon() {
    return (
        <div></div>
    )
}

export default CardPokemon;