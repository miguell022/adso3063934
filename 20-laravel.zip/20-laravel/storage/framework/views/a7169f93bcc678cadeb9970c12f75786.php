<?php echo e($slot); ?>

<?php /**PATH C:\Users\luism\OneDrive\Escritorio\adso3063934\20-laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>